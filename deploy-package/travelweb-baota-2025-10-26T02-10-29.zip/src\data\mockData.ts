// 模拟数据
export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  category: string;
  image: string;
  views: number;
  tags: string[];
}

export interface Service {
  id: string;
  title: string;
  description: string;
  duration: string;
  price: number;
  highlights: string[];
  image: string;
  category: string;
}

export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string;
  category: string;
  duration: string;
  views: number;
  date: string;
}

export interface Booking {
  id: string;
  customerName: string;
  email: string;
  phone: string;
  service: string;
  date: string;
  guests: number;
  amount: number;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  message?: string;
}

// 博客文章模拟数据
export const mockBlogPosts: BlogPost[] = [
  {
    id: '1',
    title: '成都最佳拍照地点推荐',
    excerpt: '发现成都最美的拍照圣地，记录您的美好时光',
    content: '成都作为一座历史悠久的城市，拥有众多适合拍照的美丽地点...',
    author: '张导游',
    date: '2024-01-15',
    category: 'tips',
    image: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=beautiful%20chengdu%20photography%20spots%20traditional%20architecture%20modern%20city&image_size=landscape_16_9',
    views: 1250,
    tags: ['摄影', '景点', '攻略']
  },
  {
    id: '2',
    title: '川菜文化深度解析',
    excerpt: '了解川菜的历史渊源和文化内涵',
    content: '川菜作为中国八大菜系之一，有着深厚的文化底蕴...',
    author: '张导游',
    date: '2024-01-10',
    category: 'culture',
    image: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=sichuan%20cuisine%20traditional%20chinese%20food%20spicy%20dishes%20cultural%20heritage&image_size=landscape_16_9',
    views: 980,
    tags: ['美食', '文化', '川菜']
  },
  {
    id: '3',
    title: '成都地铁出行指南',
    excerpt: '详细的成都地铁使用攻略，让您出行更便捷',
    content: '成都地铁系统日益完善，为游客提供了便捷的出行方式...',
    author: '张导游',
    date: '2024-01-05',
    category: 'guide',
    image: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=chengdu%20metro%20subway%20modern%20transportation%20city%20guide&image_size=landscape_16_9',
    views: 756,
    tags: ['交通', '地铁', '出行']
  }
];

// 服务项目模拟数据
export const mockServices: Service[] = [
  {
    id: '1',
    title: '成都经典一日游',
    description: '游览成都最具代表性的景点，感受天府文化的魅力',
    duration: '4-6小时',
    price: 299,
    highlights: ['宽窄巷子', '锦里古街', '武侯祠', '人民公园'],
    image: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=chengdu%20classic%20tour%20traditional%20streets%20ancient%20architecture%20cultural%20sites&image_size=landscape_4_3',
    category: 'classic'
  },
  {
    id: '2',
    title: '美食文化体验',
    description: '品尝正宗川菜，了解成都饮食文化的精髓',
    duration: '2-3小时',
    price: 199,
    highlights: ['火锅体验', '小吃街', '茶馆文化', '川菜制作'],
    image: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=chengdu%20food%20culture%20hotpot%20sichuan%20cuisine%20street%20food%20tea%20house&image_size=landscape_4_3',
    category: 'food'
  },
  {
    id: '3',
    title: '历史文化导览',
    description: '深度了解成都历史，探寻古蜀文明的足迹',
    duration: '3-4小时',
    price: 259,
    highlights: ['金沙遗址', '杜甫草堂', '青羊宫', '文殊院'],
    image: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=chengdu%20historical%20sites%20ancient%20temples%20cultural%20heritage%20traditional%20gardens&image_size=landscape_4_3',
    category: 'history'
  }
];

// 视频模拟数据
export const mockVideos: Video[] = [
  {
    id: '1',
    title: '宽窄巷子的一天',
    description: '跟随镜头感受宽窄巷子的古韵今风',
    thumbnail: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=kuanzhai%20alley%20chengdu%20traditional%20architecture%20ancient%20streets%20cultural%20atmosphere&image_size=landscape_16_9',
    videoUrl: '#',
    category: 'scenery',
    duration: '5:32',
    views: 2340,
    date: '2024-01-15'
  },
  {
    id: '2',
    title: '成都火锅制作全过程',
    description: '探秘正宗成都火锅的制作工艺',
    thumbnail: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=chengdu%20hotpot%20cooking%20process%20traditional%20sichuan%20cuisine%20spicy%20ingredients&image_size=landscape_16_9',
    videoUrl: '#',
    category: 'food',
    duration: '8:15',
    views: 1890,
    date: '2024-01-12'
  },
  {
    id: '3',
    title: '成都慢生活体验',
    description: '感受成都人的悠闲生活节奏',
    thumbnail: 'https://trae-api-sg.mchost.guru/api/ide/v1/text_to_image?prompt=chengdu%20slow%20life%20tea%20house%20park%20leisure%20lifestyle%20peaceful%20atmosphere&image_size=landscape_16_9',
    videoUrl: '#',
    category: 'life',
    duration: '6:48',
    views: 1567,
    date: '2024-01-10'
  }
];

// 预订模拟数据
export const mockBookings: Booking[] = [
  {
    id: '1',
    customerName: '李小明',
    email: 'lixiaoming@email.com',
    phone: '13812345678',
    service: '成都经典一日游',
    date: '2024-01-20',
    guests: 2,
    amount: 598,
    status: 'confirmed',
    message: '希望能安排上午出发'
  },
  {
    id: '2',
    customerName: '王美丽',
    email: 'wangmeili@email.com',
    phone: '13987654321',
    service: '美食文化体验',
    date: '2024-01-22',
    guests: 4,
    amount: 796,
    status: 'pending',
    message: '有素食选项吗？'
  },
  {
    id: '3',
    customerName: 'John Smith',
    email: 'john.smith@email.com',
    phone: '+1-555-0123',
    service: '历史文化导览',
    date: '2024-01-25',
    guests: 1,
    amount: 259,
    status: 'completed'
  }
];

// 统计数据
export const mockStats = {
  totalBookings: 156,
  totalRevenue: 45680,
  totalPosts: 28,
  totalViews: 12450
};